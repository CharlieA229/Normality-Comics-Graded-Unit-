<?php
/* Register for an account on the site.

   This page expects to receive a registration form via a post request. 
   
*/
ini_set('session.use_strict_mode', 1);
session_start();

require 'database.php';

// unset any previous error message
unset($_SESSION['errorMsg']);

// connect to the database
if (!connectToDb('normality')) {
	$_SESSION['errorMsg'] = "Sorry, we could not connect to the database.";
	header('location:addOrder.php');
	exit();
}

// after this point we have an open DB connection




// check the form contains all the post data
//if (!(isset($_POST["ID"]) && 
//	  isset($_POST["Quantity"]) &&
//	  isset($_POST["Date"]) &&
//	  isset($_POST["Variants"])&&
//	  isset($_POST["Paid"])&&
//	  isset($_POST["Name"])&&
//	  isset($_POST["Issue"])&&
//	  isset($_POST["Buyer"]))) {
//	header('location:index.php');
//	exit();
//}

// recover the form data


$ID = ($_POST["ID"]);
$Quantity = ($_POST["Quantity"]);
$Date = ($_POST["Date"]);
$Variants = ($_POST["Variants"]);
$Paid = ($_POST["Paid"]);
$Name = trim($_POST["Name"]);
$Issue = ($_POST["Issue"]);
$Buyer = ($_POST["Buyer"]);




// check if the order already exists

$query = "SELECT * FROM order WHERE Order_Id = $ID" ;
$result = $dbConnection->query($query);
if ($result->num_rows > 0) {
	closeConnection();
	$_SESSION['errorMsg'] = "This Order already exists ";
	header('location:addOrder.php');
	exit();
}

// check if there is an existing buyer
$query = "SELECT * FROM buyer WHERE Buyer_Id = $Buyer" ;
$result = $dbConnection->query($query);
if ($result->num_rows !=1) {
	closeConnection();
	$_SESSION['errorMsg'] = "This buyer doesn't  exist ";
	header('location:addOrder.php');
	exit();
}




// add the new user details to the database
$Name = sanitizeString($Name);

$query = "INSERT INTO order (Order_Id, Quantity, Order_Date, No_of_Varients, Paid_Status, Comic_Name, Comic_Issue, Buyer_Id) VALUES ($ID, $Quantity, $Date, $Variants, $Paid, '$Name', $Issue, $Buyer)";
$result = $dbConnection->query($query);
if (!$result) {
	$_SESSION['errorMsg'] = "There was a problem with the database: " . $dbConnection->error;
	
	closeConnection();
	header('location:addOrder.php');
	exit();
}

// everything worked, update the session info
closeConnection();


header('Location:orders.php');
?>