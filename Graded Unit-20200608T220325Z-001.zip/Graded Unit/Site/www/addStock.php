<!DOCTYPE html>
<?php
require 'database.php';
require 'pageElements.php';

ini_set('session.use_strict_mode', 1);
session_start();
?>

<html>
    <head>
        <title>Add Stock</title>

<?php writeCommonStyles(); ?>		
		
		
    </head>  
    
    <body>
        <div id="container">
		
            <div id="header"></div>

			<?php displayMenu(STOCK); ?>

            <div id="content" style="overflow:auto;">
			
			<h1>Add New Stock Item</h1>
			
<?php
// if there is an error from the previous registration attempt then display it
if (isset($_SESSION['errorMsg'])) {
	$errorMsg = $_SESSION['errorMsg'];
	echo "<p>$errorMsg";
	unset($_SESSION['errorMsg']);
}
?>

			<form action="processAddStock.php"  name="addStockForm" method="post">
			<table class="twoColForm">
			<tr><td>Please enter comic name:</td><td><input type="text" name="Name" required></td></tr>
			<tr><td>Please enter issue number:</td><td><input type="number" name="Issue" required></td></tr>
			<tr><td>Please enter stock left :</td><td><input type="number" name="Stock_Left" required></td></tr>
			<tr><td>Please enter issue cost:</td><td><input type="number" name="Issue_Cost" step="0.01" required></td></tr>
			<tr><td>Please enter number of requests :</td><td><input type="number" name="Number_of_Requests" value = 0 ></td></tr>
			<tr><td colspan="2"><input type="submit" value="Add"></td></tr>
			</table>
			</form>
			
			</div>

            
        
        </div>
    
    </body>    
</html>
