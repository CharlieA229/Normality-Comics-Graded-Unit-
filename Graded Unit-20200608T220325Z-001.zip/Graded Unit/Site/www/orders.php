<!DOCTYPE html>
<?php
require 'userSession.php';
require 'pageElements.php';
require 'database.php';
?>

<html>
    <head>
        <title>Normality Comics</title>
    
<?php writeCommonStyles(); ?>		
<link href="css/table.css" rel="stylesheet" type="text/css"/>		
    </head>  
    
    <body>
        <div id="container">
            
            <div id="header"><?php displaySignIn(); ?><h1>Orders Page</h1></div>

			<?php displayMenu(ORDERS); ?>

            <div id="content" style="overflow:auto;">
			
			<h1>Orders</h1>
			
			<?php
			// connect to the database
			if (!connectToDb('normality')) {
			$_SESSION['errorMsg'] = "Sorry, we could not connect to the database.";
			header('location:index.php');
			exit();
			}
			
			// after this point we have an open DB connection
			
			// check table has values
			
			$query = "SELECT * FROM `order`";
			$result = $dbConnection->query($query);
			if ($result->num_rows == 0) {
				closeConnection();
				$_SESSION['errorMsg'] = "Sorry - unexpected problem with the database";
				header('location:index.php');
				exit();
			}
				
			echo '<table >';
				echo '<thead>';
					echo'<tr>';
						echo'<th> Order ID </th>';
						echo'<th> Quantity  </th>';
						echo'<th> Order Date </th>';
						echo'<th> Number Of Variant Covers </th>';
						echo'<th> Paid Status </th>';
						echo'<th> Comic Name </th>';
						echo'<th> Comic Issue </th>';
						echo'<th> Buyer ID </th>';
					echo'</tr>';
				echo'</thead>';
			
				echo'<tbody>';
			
				// run query to get field names 
				$result = $dbConnection->query($query);
				//return only the first row (we only need field names)
				while ($row = $result->fetch_assoc()) {
					$field1name = $row["Order_Id"];
					$field2name = $row["Quantity"];
					$field3name = $row["Order_Date"];
					$field4name = $row["No_of_Varients"];
					$field5name = $row["Paid_Status"]; 
					$field6name = $row["Comic_Name"];
					$field7name = $row["Comic_Issue"];
					$field8name = $row["Buyer_Id"];
 
					echo '<tr> 
						<td>'.$field1name.'</td> 
						<td>'.$field2name.'</td> 
						<td>'.$field3name.'</td> 
						<td>'.$field4name.'</td> 
						<td>'.$field5name.'</td> 
						<td>'.$field6name.'</td> 
						<td>'.$field7name.'</td> 
						<td>'.$field8name.'</td> 
					</tr>';
					
				}
				echo'</tbody>';
			echo'</table>';
    
//https://www.sitepoint.com/community/t/how-to-display-data-from-a-database-into-a-html-table/241123/5
           ?>
			
			 
		 <form class = "buttons">
			<input class = "button" type="button" value="AddOrder" onclick="window.location.href='addOrder.php'" />
			<input class = "button" type="button" value="EditStock" onclick="window.location.href='addStock.php'" />
			<input class = "button" type="button" value="RemoveStock" onclick="window.location.href='addStock.php'" />
		</form>

			
			
			</div>

        </div>
    
    </body>    
</html>