<!DOCTYPE html>
<?php
require 'userSession.php';
require 'pageElements.php';
?>

<html>
    <head>
        <title>Normality Comics</title>
    
<?php writeCommonStyles(); ?>		
		
    </head>  
    
    <body>
        <div id="container">
            
            <div id="header"><?php displaySignIn(); ?><h1>About</h1></div>

			<?php displayMenu(ABOUT); ?>

            <div id="content" style="overflow:auto;">
			
			<h1>About Us</h1>
			
			<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec gravida libero volutpat nisi consequat imperdiet. Donec turpis metus, fermentum sit amet lacinia sollicitudin, eleifend nec metus. 
			<p>Phasellus semper, purus sed laoreet venenatis, turpis velit consectetur augue, eu vestibulum nisi eros quis sapien. Pellentesque et vehicula metus. 
			<p>Ut venenatis sem lectus. Nulla et tempor nisl. Curabitur ut orci nec leo feugiat venenatis sed non ex. Sed non lorem nec est volutpat aliquam vel non mauris. 
			<p>Morbi a augue elit. Duis lobortis accumsan nulla, vehicula fringilla ante scelerisque at. Ut gravida consectetur ex sed bibendum. Nam egestas scelerisque ipsum nec dignissim. 
			<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.
			
			
			
			
			
			</div>

        
        </div>
    
    </body>    
</html>







