<!DOCTYPE html>
<?php
require 'userSession.php';
require 'pageElements.php';
require 'database.php';
?>

<html>
    <head>
        <title>Normality Comics</title>
    
<?php writeCommonStyles(); ?>		
		
    </head>  
    
    <body>
        <div id="container">
            
            <div id="header"><?php displaySignIn(); ?><h1>Stock Page</h1></div>

			<?php displayMenu(STOCK); ?>

            <div id="content" style="overflow:auto;">
			
			<h1>Stock Page</h1>
			<?php
			// connect to the database
			if (!connectToDb('normality')) {
			$_SESSION['errorMsg'] = "Sorry, we could not connect to the database.";
			header('location:index.php');
			exit();
			}
			
			// after this point we have an open DB connection
			
			// check table has values
			
			$query = "SELECT * FROM comic";
			$result = $dbConnection->query($query);
			if ($result->num_rows == 0) {
				closeConnection();
				$_SESSION['errorMsg'] = "Sorry - unexpected problem with the database";
				header('location:index.php');
				exit();
			}
				
			echo '<table> n';
			
			// run query to get field names 
			$result = $dbConnection->query($query);
			//return only the first row (we only need field names)
			$row = $result->fetch_assoc();
			
			echo ' <tr> n';
			
			foreach ($row as $field => $value){
				echo ' <th>$field</th> n';
			} // end foreach
			
			echo ' </tr> n';
			
			
			//second query gets the data
			$data = $dbConnection->query($query);
			$data->fetch_assoc();
			
			foreach($data as $row){
				echo ' <tr> n';
				foreach ($row as $name=>$value){
					echo ' <td>$value</td> n';
				} // end field loop
				echo ' </tr> n';
			} // end record loop

           ?>
        
        </div>
    
    </body>    
</html>