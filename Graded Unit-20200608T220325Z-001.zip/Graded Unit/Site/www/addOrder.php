<!DOCTYPE html>
<?php
require 'database.php';
require 'pageElements.php';

ini_set('session.use_strict_mode', 1);
session_start();
?>

<html>
    <head>
        <title>Add Order</title>

<?php writeCommonStyles(); ?>		
		
		
    </head>  
    
    <body>
        <div id="container">
		
            <div id="header"></div>

			<?php displayMenu(ORDERS); ?>

            <div id="content" style="overflow:auto;">
			
			<h1>Add New Order </h1>
			
<?php
// if there is an error from the previous registration attempt then display it
if (isset($_SESSION['errorMsg'])) {
	$errorMsg = $_SESSION['errorMsg'];
	echo "<p>$errorMsg";
	unset($_SESSION['errorMsg']);
}
?>

			<form action="processAddOrder.php"  name="addOrderForm" method="post">
			<table class="twoColForm">
			<tr><td>Please enter Order ID:</td><td><input type="number" name="ID" required></td></tr>
			<tr><td>Please enter The Quantity :</td><td><input type="number" name="Quantity" required></td></tr>
			<tr><td>Please enter Order Date :</td><td><input type="date" name="Date" required></td></tr>
			<tr><td>Please enter Number Of Variants :</td><td><input type="number" name="Variants" value=" required></td></tr>
			<tr><td>Please enter Paid Status (Y/N) :</td><td><input type="text" name="Paid" value = "N" ></td></tr>
			<tr><td>Please enter Comic Name :</td><td><input type="Text" name="Name" required></td></tr>
			<tr><td>Please enter Comic Issue :</td><td><input type="number" name="Issue" required></td></tr>
			<tr><td>Please enter Buyer ID  :</td><td><input type="number" name="Buyer"required></td></tr>
			<tr><td colspan="2"><input type="submit" value="Add"></td></tr>
			</table>
			</form>
			
			</div>

            
        
        </div>
    
    </body>    
</html>
