<?php
/* The functions defined in this file are used to create various 
   structural elements in the pages.
   
   Author: Andreas Schoter
*/

/* Constants defining the top level menu items in the site
   Note that the numerical values of these constants need to
   match up with the menuItems array defined in the displayMenu
   function.
*/
const HOME = 0;
const STOCK = 1;
const ORDERS = 2;
const REPORTS =3;
const ACCOUNT = 4;
CONST ABOUT = 5;

function writeCommonStyles()
{
?>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css"/>
<?php	
}

/* Display the menu in a page.
*/
function displayMenu($section)
{
	// the top level menu items are stored as an array
	$menuItems = array('<a href="index.php" id="Home">Home</a>',
					   '<a href="stock.php" id="Stock">Stock Page</a>',
					   '<a href="orders.php" id="Orders">Orders Page</a>',
					   '<a href="reports.php" id="Reports">Reports Page</a>',
					   '<a href="account.php" id="Account">Account Info</a>',
					   '<a href="about.php" id="About">About Us </a>');
	
	// write the opening structure of the menu
	echo '<div id="menu">
			<div class="menuBackground">
				<ul>';
				
	// write the individual menu items
	$menuCount = count($menuItems);
	for ($i = 0; $i < $menuCount; $i++) {
		echo "\n<li";
		if ($section == $i) { // if an item is selected, add the correct class spec
			echo " class='active'";
		}
		echo ">" . $menuItems[$i];
	}
	
	// write the closing structure of the menu
	echo "\n</ul>
			</div>
		</div>";
}


/* Display the user form. If the user has not signed in, then this will be a sign-in
   form asking for their name. If they are signed in, it will be a sign-out form.
*/
function displaySignIn()
{
	// need to specify we want to access the global variable
	global $userName;
	
	// if there is no username set then we need to offer the sign in form or registration link
	if ($userName == '') {
		echo '<span id="signin"><form action="processSignIn.php" name="signInForm" onsubmit="return validateUserName(\'signInForm\');" method="post"><table border="0"><tr><td align="right">Please enter your user name:</td><td><input type="text" name="userName" required></td></tr><tr><td align="right">Password:</td><td><input type="password" name="pw" required></td></tr><tr><td colspan="2" align="right"><input type="submit" value="Sign In!"></td></tr></table></form><br>or <a href="registration.php">register here...</a></span>';
	}
	else { // otherwise, we offer the sign out form
		echo '<span id="signout"><form action="processSignOut.php" method="post">Welcome ' . $userName . ' <input type="submit" value="Sign Out"></form></span>';
	}
}
?>