<?php
/* 
   This file defines the functions that display the common features of the pages 
  
*/

/* The Constants are numbers that represent each page in a numerical way this is used to show which page 
	is the active page in the displayMenu Function. These numbers must be in the correct order as the 
	pages appear in the menu.
*/
const HOME = 0;
const STOCK = 1;
const ORDERS = 2;
const REPORTS =3;
const ACCOUNT = 4;
CONST ABOUT = 5;


/*
	Used to write in each page so that they can access the style sheets needed to use them.
*/

function writeCommonStyles()
{
?>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/menu.css" rel="stylesheet" type="text/css"/>
<?php	
}

/* Display the menu in a page. Take in a value that corresponds to the constants defined above 
	used to show what page is selected.
*/
function displayMenu($section)
{
	// the  menu items are stored as an array so it can be printed the same every time
	$menuItems = array('<a href="index.php" id="Home">Home</a>',
					   '<a href="stock.php" id="Stock">Stock Page</a>',
					   '<a href="orders.php" id="Orders">Orders Page</a>',
					   '<a href="reports.php" id="Reports">Reports Page</a>',
					   '<a href="account.php" id="Account">Account Info</a>',
					   '<a href="about.php" id="About">About Us </a>');
	
	// Open the menu tag 
	echo '<div id="menu">
			<div class="menuBackground">
				<ul>';
				
	// Get the number of items in the menuItems array
	$menuCount = count($menuItems);
	// write the contents of the array
	for ($i = 0; $i < $menuCount; $i++) {
		echo "\n<li";
		if ($section == $i) { // if an item is selected, add the correct class spec
			echo " class='active'";
		}
		echo ">" . $menuItems[$i];
	}
	
	// Close the menu tab
	echo "\n</ul>
			</div>
		</div>";
}


/* Display the sign in form will show sign in and sign out when appropriate 
*/
function displaySignIn()
{
	// need to specify we want to access the global variable
	global $userName;
	
	// if there is no username set for the session  then we need to offer the sign in form 
	if ($userName == '') {
		echo '<span id="signin"><form action="processSignIn.php" name="signInForm" onsubmit="return validateUserName(\'signInForm\');" method="post"><table border="0"><tr><td align="right">Please enter your user name:</td><td><input type="text" name="userName" required></td></tr><tr><td align="right">Password:</td><td><input type="password" name="pw" required></td></tr><tr><td colspan="2" align="right"><input type="submit" value="Sign In!"></td></tr></table></form></span>';
	}
	else { // otherwise, we show the sign out form
		echo '<span id="signout"><form action="processSignOut.php" method="post">Welcome ' . $userName . ' <input type="submit" value="Sign Out"></form></span>';
	}
}


/* Display the footer information.
*/
function displayFooter()
{
	echo '<a href="https://docs.google.com/document/d/1_diRh2h7ypv-gvl6Ff6TLb3KIbm7yux_c2985Hx-IJY/edit?usp=sharing" >Help</a>';
}
?>
