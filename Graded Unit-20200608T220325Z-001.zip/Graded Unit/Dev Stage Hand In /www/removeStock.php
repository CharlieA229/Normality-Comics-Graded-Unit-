<!DOCTYPE html>

<!--
Allows users to view the orders and then enter the information they want deleted
-->

<?php
require 'userSession.php';
require 'pageElements.php';
require 'database.php';
?>

<html>
    <head>
        <title>Normality Comics</title>
    
<?php writeCommonStyles(); ?>	
<link href="css/table.css" rel="stylesheet" type="text/css"/>
		
    </head>  
    
    <body>
        <div id="container">
            
            <div id="header"><?php displaySignIn(); ?><h1>Stock Page</h1></div>

			<?php displayMenu(STOCK); ?>

            <div id="content" style="overflow:auto;">
			
			<h1>Remove Stock Page</h1>
			<?php
			// displays any errors from a sign in attempt 
			$errMsg = null;
				if (isset($_SESSION['errorMsg'])) {
				$errMsg = $_SESSION['errorMsg'];
				echo "onload='displayError(\"$errMsg\");'";
				unset($_SESSION['errorMsg']);
			}
			
			
			// connect to the database
			if (!connectToDb('normality')) {
			$_SESSION['errorMsg'] = "Sorry, we could not connect to the database.";
			header('location:index.php');
			exit();
			}
			
			// after this point we have an open DB connection
			
			// check table has values
			
			$query = "SELECT * FROM comic"; // create query to show all the comics 
			$result = $dbConnection->query($query);// run the query 
			if ($result->num_rows == 0) {
				closeConnection();
				$_SESSION['errorMsg'] = "Sorry - unexpected problem with the database"; // display error if it doesn't return anything
				header('location:removeStock.php'); 
				exit();
			}
			// create the table heads 	
			echo '<table>';
				echo '<thead>';
					echo'<tr>';
						echo'<th> Comic Name </th>';
						echo'<th> Comic Issue </th>';
						echo'<th> Stock Left </th>';
						echo'<th> Issue Cost </th>';
						echo'<th> Number of Reprint Requests </th>';
					echo'</tr>';
				echo'</thead>';
			
				echo'<tbody>';
			
				// run query to get fields  
				$result = $dbConnection->query($query); // can use the same one again 
				//return the rows of the table
				while ($row = $result->fetch_assoc()) {
					$field1 = $row["Name"];
					$field2 = $row["Issue"];
					$field3 = $row["Stock_Left"];
					$field4 = $row["Issue_Cost"];
					$field5 = $row["Number_of_Requests"]; 
 
 
					// display the results in the table
					echo '<tr> 
						<td>'.$field1.'</td> 
						<td>'.$field2.'</td> 
						<td>'.$field3.'</td> 
						<td>'.$field4.'</td> 
						<td>'.$field5.'</td> 
					</tr>';
					
				}
				echo'</tbody>';
			echo'</table>';
    
//https://www.sitepoint.com/community/t/how-to-display-data-from-a-database-into-a-html-table/241123/5
           ?>
		 <!--
				Show a form that allows the user to enter comic information that is
				passed on to the processRemoveStock page and is removed from the database
				
				Makes both value required 
		 --> 
		 <form action="processRemoveStock.php"  name="removeStockForm" method="post">
			<table class="twoColForm">
			<tr><td>Please enter comic name to be removed:</td><td><input type="text" name="Name" required></td></tr>
			<tr><td>Please enter issue number to be removed :</td><td><input type="number" name="Issue" required></td></tr>
			<tr><td colspan="2"><input type="submit" value="Remove"></td></tr>
			</table>
		</form>

			
		  
        </div>
       </div>
    
    </body>    
</html>