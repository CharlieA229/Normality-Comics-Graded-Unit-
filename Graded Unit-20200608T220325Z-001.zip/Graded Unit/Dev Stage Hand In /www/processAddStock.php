<?php
/* Register for an account on the site.

   This page expects to receive a registration form via a post request. 
   
*/
ini_set('session.use_strict_mode', 1);
session_start();

require 'database.php';

// unset any previous error message
unset($_SESSION['errorMsg']);


// connect to the database
if (!connectToDb('normality')) {
	$_SESSION['errorMsg'] = "Sorry, we could not connect to the database.";
	header('location:addStock.php');
	exit();
}

// after this point we have an open DB connection




// check the form contains all the post data
if (!(isset($_POST["Name"]) && 
	  isset($_POST["Issue"]) &&
	  isset($_POST["Stock_Left"]) &&
	  isset($_POST["Issue_Cost"]))) {
	header('location:index.php');
	exit();
}

// recover the form data
$Name = trim($_POST["Name"]);

$Issue = ($_POST["Issue"]);
$Stock = ($_POST["Stock_Left"]);
$Cost = ($_POST["Issue_Cost"]);
$Requests = ($_POST["Number_of_Requests"]);






// check if the comic already exists
$Name = sanitizeString($Name);


$query = "SELECT * FROM comic WHERE Name='$Name' AND Issue =$Issue";
$result = $dbConnection->query($query);
if ($result->num_rows > 0) {
	closeConnection();
	$_SESSION['errorMsg'] = "This Comic already exists ";
	header('location:addStock.php');
	exit();
}

// add the new user details to the database
$Name = sanitizeString($Name);



$query = "INSERT INTO comic (Name, Issue, Stock_Left, Issue_Cost, Number_of_Requests) VALUES ('$Name', $Issue, $Stock, $Cost, $Requests)";
$result = $dbConnection->query($query);
if (!$result) {
	$_SESSION['errorMsg'] = "There was a problem with the database: " . $dbConnection->error. $Name.$Issue.$Cost.$Stock.$Requests;
	
	closeConnection();
	header('location:addStock.php');
	exit();
}

// everything worked, update the session info
closeConnection();


header('Location:stock.php');
?>