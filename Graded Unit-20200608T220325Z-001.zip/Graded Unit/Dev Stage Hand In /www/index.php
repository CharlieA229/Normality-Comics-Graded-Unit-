<!DOCTYPE html>
<!-- 
	The front page of the site.
-->
<?php
require 'userSession.php';
require 'pageElements.php';
?>

<html>
    <head>
        <title>Normality Comics</title>

<?php writeCommonStyles(); ?>		
		
		<script src="js/validateForm.js" type="text/javascript"></script>
		<script type="text/javascript">
		function displayError(msg) {
			alert("Problem signing in: "+msg);
		}
		</script>
    </head>  
    
    <body 
<?php
	// check for a sign in error and post an alert if necessary
	$errMsg = null;
	if (isset($_SESSION['errorMsg'])) {
		$errMsg = $_SESSION['errorMsg'];
		echo "onload='displayError(\"$errMsg\");'";
		unset($_SESSION['errorMsg']);
	}
?>
	>
        <div id="container">
            <div id="header"><h1>Home</h1><?php displaySignIn(); ?></div>
			<?php displayMenu(HOME); ?>
			
            <div id="content" style="overflow:auto;">
			
			<h1>Welcome</h1>
			
			
			<img src="../img/cover.png" alt="Comic Cover" width="250" height="300" align = "right">
			<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec gravida libero volutpat nisi consequat imperdiet. Donec turpis metus, fermentum sit amet lacinia sollicitudin, eleifend nec metus. 
			<p>Phasellus semper, purus sed laoreet venenatis, turpis velit consectetur augue, eu vestibulum nisi eros quis sapien. Pellentesque et vehicula metus.
			
			<p>Ut venenatis sem lectus. Nulla et tempor nisl. Curabitur ut orci nec leo feugiat venenatis sed non ex. Sed non lorem nec est volutpat aliquam vel non mauris. 
			<p>Morbi a augue elit. Duis lobortis accumsan nulla, vehicula fringilla ante scelerisque at. Ut gravida consectetur ex sed bibendum. Nam egestas scelerisque ipsum nec dignissim. 
			<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.
			
			
			</div>

                <?php displayFooter(); ?>
        
        </div>

    </body>    
</html>
