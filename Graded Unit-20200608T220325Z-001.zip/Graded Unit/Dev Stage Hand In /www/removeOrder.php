<!DOCTYPE html>

<!--
Allows users to view the orders and then enter the information they want deleted
-->

<?php
require 'userSession.php';
require 'pageElements.php';
require 'database.php';
?>

<html>
    <head>
        <title>Normality Comics</title>
    
<?php writeCommonStyles(); ?>	
<link href="css/table.css" rel="stylesheet" type="text/css"/>
		
    </head>  
    
    <body>
        <div id="container">
            
            <div id="header"><?php displaySignIn(); ?><h1></h1></div>

			<?php displayMenu(ORDERS); ?>

            <div id="content" style="overflow:auto;">
			
			<h1>Remove Order Page</h1>
			<?php
			// displays any errors from a sign in attempt 
			$errMsg = null;
				if (isset($_SESSION['errorMsg'])) {
				$errMsg = $_SESSION['errorMsg'];
				echo "onload='displayError(\"$errMsg\");'";
				unset($_SESSION['errorMsg']);
			}
			
			
			// connect to the database
			if (!connectToDb('normality')) {
			$_SESSION['errorMsg'] = "Sorry, we could not connect to the database.";
			header('location:index.php');
			exit();
			}
			
			// after this point we have an open DB connection
			
				// check table has values
			
			$query = "SELECT * FROM `order`"; // create the needed query 
			$result = $dbConnection->query($query); // run the query in the database
			if ($result->num_rows == 0) {
				closeConnection();
				$_SESSION['errorMsg'] = "Sorry - unexpected problem with the database"; // display error if no values in the table
				header('location:index.php');
				exit();
			}
			// create the table headings
			echo '<table >';
				echo '<thead>';
					echo'<tr>';
						echo'<th> Order ID </th>';
						echo'<th> Quantity  </th>';
						echo'<th> Order Date </th>';
						echo'<th> Number Of Variant Covers </th>';
						echo'<th> Paid Status </th>';
						echo'<th> Comic Name </th>';
						echo'<th> Comic Issue </th>';
						echo'<th> Buyer ID </th>';
					echo'</tr>';
				echo'</thead>';
			
				echo'<tbody>';
			
				// run query to get field from table 
				// use the same query made earlier
				$result = $dbConnection->query($query);
				//for every row in the query results save the rows values as fields 
				while ($row = $result->fetch_assoc()) {
					$field1 = $row["Order_Id"];
					$field2 = $row["Quantity"];
					$field3 = $row["Order_Date"];
					$field4 = $row["No_of_Varients"];
					$field5 = $row["Paid_Status"]; 
					$field6 = $row["Comic_Name"];
					$field7 = $row["Comic_Issue"];
					$field8 = $row["Buyer_Id"];
				
				
				// display the fields in the table
					echo '<tr> 
						<td>'.$field1.'</td> 
						<td>'.$field2.'</td> 
						<td>'.$field3.'</td> 
						<td>'.$field4.'</td> 
						<td>'.$field5.'</td> 
						<td>'.$field6.'</td> 
						<td>'.$field7.'</td> 
						<td>'.$field8.'</td> 
					</tr>';
					
				}
				echo'</tbody>';
			echo'</table>';
    
//https://www.sitepoint.com/community/t/how-to-display-data-from-a-database-into-a-html-table/241123/5
           ?>
		 <!--
				Show a form that allows the user to enter comic information that is
				passed on to the processRemoveStock page and is removed from the database
				
				Makes both value required 
		 --> 
		 <form action="processRemoveOrder.php"  name="removeOrderForm" method="post">
			<table class="twoColForm">
			<tr><td>Please enter order id to be removed :</td><td><input type="number" name="ID" required></td></tr>
			<tr><td colspan="2"><input type="submit" value="Remove"></td></tr>
			</table>
		</form>

			
		  
        </div>
       </div>
    
    </body>    
</html>