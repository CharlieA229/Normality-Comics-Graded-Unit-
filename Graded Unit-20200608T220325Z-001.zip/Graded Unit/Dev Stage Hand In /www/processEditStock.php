<?php
/* Register for an account on the site.

   This page expects to receive a registration form via a post request. 
   
*/
ini_set('session.use_strict_mode', 1);
session_start();

require 'database.php';

// unset any previous error message
unset($_SESSION['errorMsg']);


// connect to the database
if (!connectToDb('normality')) {
	$_SESSION['errorMsg'] = "Sorry, we could not connect to the database.";
	header('location:editStock.php');
	exit();
}

// after this point we have an open DB connection




// check the form contains all the post data
if (!(isset($_POST["Name"]) && 
	  isset($_POST["NName"]) &&
	  isset($_POST["NIssue"]) &&
	  isset($_POST["Issue"]) &&
	  isset($_POST["Stock_Left"]) &&
	  isset($_POST["Issue_Cost"]))) {
	header('location:editStock.php');
	exit();
}

// recover the form data
$Name = trim($_POST["Name"]);
$Issue = ($_POST["Issue"]);

$NewName= trim($_POST["NName"]);
$NewIssue = ($_POST["NIssue"]);
$Stock = ($_POST["Stock_Left"]);
$Cost = ($_POST["Issue_Cost"]);
$Requests = ($_POST["Number_of_Requests"]);






// check if the comic already exists to be edited 
$Name = sanitizeString($Name);


$query = "SELECT * FROM comic WHERE Name='$Name' AND Issue =$Issue";
$result = $dbConnection->query($query);
if ($result->num_rows == 0) {
	closeConnection();
	$_SESSION['errorMsg'] = "This Comic Does Not Exist exists ";
	header('location:editStock.php');
	exit();
}

// add the new user details to the database
$NewName = sanitizeString($NewName);



$query = "UPDATE comic SET Name = '$NewName', Issue =$NewIssue, Stock_Left=$Stock, Issue_Cost=$Cost, Number_of_Requests=$Requests WHERE Name='$Name' AND Issue =$Issue ";
$result = $dbConnection->query($query);
if (!$result) {
	$_SESSION['errorMsg'] = "There was a problem with the database: " . $dbConnection->error. $Name.$Issue.$Cost.$Stock.$Requests;
	
	closeConnection();
	header('location:editStock.php');
	exit();
}

// everything worked, update the session info
closeConnection();


header('Location:stock.php');
?>