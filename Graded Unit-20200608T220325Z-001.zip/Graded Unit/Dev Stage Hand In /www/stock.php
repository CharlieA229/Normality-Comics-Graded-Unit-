<!DOCTYPE html>
<?php
require 'userSession.php';
require 'pageElements.php';
require 'database.php';
?>

<html>
    <head>
        <title>Normality Comics</title>
    
<?php writeCommonStyles(); ?>	
<link href="css/table.css" rel="stylesheet" type="text/css"/>
		
    </head>  
    
    <body>
        <div id="container">
            
            <div id="header"><?php displaySignIn(); ?><h1>Stock Page</h1></div>

			<?php displayMenu(STOCK); ?>

            <div id="content" style="overflow:auto;">
			
			<h1>Stock Page</h1>
			<?php
			// connect to the database
			if (!connectToDb('normality')) {
			$_SESSION['errorMsg'] = "Sorry, we could not connect to the database.";
			header('location:index.php');
			exit();
			}
			
			// after this point we have an open DB connection
			
			// check table has values
			
			$query = "SELECT * FROM comic";
			$result = $dbConnection->query($query);
			if ($result->num_rows == 0) {
				closeConnection();
				$_SESSION['errorMsg'] = "Sorry - unexpected problem with the database";
				header('location:index.php');
				exit();
			}
				
			echo '<table>';
				echo '<thead>';
					echo'<tr>';
						echo'<th> Comic Name </th>';
						echo'<th> Comic Issue </th>';
						echo'<th> Stock Left </th>';
						echo'<th> Issue Cost </th>';
						echo'<th> Number of Reprint Requests </th>';
					echo'</tr>';
				echo'</thead>';
			
				echo'<tbody>';
			
				// run query to get field names 
				$result = $dbConnection->query($query);
				//return only the first row (we only need field names)
				while ($row = $result->fetch_assoc()) {
					$field1name = $row["Name"];
					$field2name = $row["Issue"];
					$field3name = $row["Stock_Left"];
					$field4name = $row["Issue_Cost"];
					$field5name = $row["Number_of_Requests"]; 
 
					echo '<tr> 
						<td>'.$field1name.'</td> 
						<td>'.$field2name.'</td> 
						<td>'.$field3name.'</td> 
						<td>'.$field4name.'</td> 
						<td>'.$field5name.'</td> 
					</tr>';
					
				}
				echo'</tbody>';
			echo'</table>';
    
//https://www.sitepoint.com/community/t/how-to-display-data-from-a-database-into-a-html-table/241123/5
           ?>
		  
		 <form class = " buttons">
			<input class = "button" type="button" value="AddStock" onclick="window.location.href='addStock.php'" />
			<input class = "button" type="button" value="EditStock" onclick="window.location.href='editStock.php'" />
			<input class = "button" type="button" value="RemoveStock" onclick="window.location.href='removeStock.php'" />
		</form>

			
		  
        </div>
			    <?php displayFooter(); ?>
       </div>
    
    </body>    
</html>