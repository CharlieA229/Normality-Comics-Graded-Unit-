<!DOCTYPE html>
<?php
require 'database.php';
require 'pageElements.php';

ini_set('session.use_strict_mode', 1);
session_start();
?>

<html>
    <head>
        <title>Edit Stock</title>

<?php writeCommonStyles(); ?>		
<link href="css/table.css" rel="stylesheet" type="text/css"/>		
		
    </head>  
    
    <body>
        <div id="container">
		
            <div id="header"></div>

			<?php displayMenu(STOCK); ?>

            <div id="content" style="overflow:auto;">
			
			<h1>Edit Stock Item</h1>
			
<?php
// if there is an error from the previous registration attempt then display it
if (isset($_SESSION['errorMsg'])) {
	$errorMsg = $_SESSION['errorMsg'];
	echo "<p>$errorMsg";
	unset($_SESSION['errorMsg']);
}

// connect to the database
			if (!connectToDb('normality')) {
			$_SESSION['errorMsg'] = "Sorry, we could not connect to the database.";
			header('location:index.php');
			exit();
			}
			
			// after this point we have an open DB connection
			
			// check table has values
			
			$query = "SELECT * FROM comic";
			$result = $dbConnection->query($query);
			if ($result->num_rows == 0) {
				closeConnection();
				$_SESSION['errorMsg'] = "Sorry - unexpected problem with the database";
				header('location:index.php');
				exit();
			}
				
			echo '<table>';
				echo '<thead>';
					echo'<tr>';
						echo'<th> Comic Name </th>';
						echo'<th> Comic Issue </th>';
						echo'<th> Stock Left </th>';
						echo'<th> Issue Cost </th>';
						echo'<th> Number of Reprint Requests </th>';
					echo'</tr>';
				echo'</thead>';
			
				echo'<tbody>';
			
				// run query to get field names 
				$result = $dbConnection->query($query);
				//return only the first row (we only need field names)
				while ($row = $result->fetch_assoc()) {
					$field1name = $row["Name"];
					$field2name = $row["Issue"];
					$field3name = $row["Stock_Left"];
					$field4name = $row["Issue_Cost"];
					$field5name = $row["Number_of_Requests"]; 
 
					echo '<tr> 
						<td>'.$field1name.'</td> 
						<td>'.$field2name.'</td> 
						<td>'.$field3name.'</td> 
						<td>'.$field4name.'</td> 
						<td>'.$field5name.'</td> 
					</tr>';
					
				}
				echo'</tbody>';
			echo'</table>';
			
			?>
			
			<form action="processEditStock.php"  name="addStockForm" method="post">
			<table class="twoColForm">
			
			<tr><td>Please enter comic name to be edited :</td><td><input type="text" name="Name" required></td></tr>
			<tr><td>Please enter issue number to be edited :</td><td><input type="number" name="Issue" required></td></tr>
			<tr><td>Please enter new comic name:</td><td><input type="text" name="NName" required></td></tr>
			<tr><td>Please enter new issue number:</td><td><input type="number" name="NIssue" required></td></tr>
			<tr><td>Please enter new stock left :</td><td><input type="number" name="Stock_Left" required></td></tr>
			<tr><td>Please enter new issue cost:</td><td><input type="number" name="Issue_Cost" step="0.01" required></td></tr>
			<tr><td>Please enter new number of requests :</td><td><input type="number" name="Number_of_Requests" value = 0 ></td></tr>
			<tr><td colspan="2"><input type="submit" value="Edit"></td></tr>
			</table>
			</form>
			
			</div>

                <?php displayFooter(); ?>
        
        </div>
    
    </body>    
</html>
