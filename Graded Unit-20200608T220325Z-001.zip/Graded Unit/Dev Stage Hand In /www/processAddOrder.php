<?php
/* Process the creation of a new order 
   
*/

ini_set('session.use_strict_mode', 1);
session_start();

require 'database.php';



$errMsg = null;
	if (isset($_SESSION['errorMsg'])) {
		$errMsg = $_SESSION['errorMsg'];
		echo "onload='displayError(\"$errMsg\");'";
		unset($_SESSION['errorMsg']);
	}



// unset any previous error message
unset($_SESSION['errorMsg']);

// connect to the database
if (!connectToDb('normality')) {
	$_SESSION['errorMsg'] = "Sorry, we could not connect to the database.";
	header('location:addOrder.php');
	exit();
}

// after this point we have an open DB connection




// check the form contains all the post data send to home page if not.
if (!(isset($_POST["ID"]) && 
	  isset($_POST["Quantity"]) &&
	  isset($_POST["Date"]) &&
	  isset($_POST["Variants"])&&
	  isset($_POST["Paid"])&&
	  isset($_POST["Name"])&&
	  isset($_POST["Issue"])&&
	  isset($_POST["Buyer"]))) {
	header('location:index.php');
	exit();
}

// recover the form data


$ID = ($_POST["ID"]);
$Quantity = ($_POST["Quantity"]);
$Date = ($_POST["Date"]);
$Variants = ($_POST["Variants"]);
$Paid = trim($_POST["Paid"]);
$Name = trim($_POST["Name"]);
$Issue = ($_POST["Issue"]);
$Buyer = ($_POST["Buyer"]);




// check if the order already exists

$query = "SELECT * FROM order WHERE Order_Id = $ID" ;
$result = $dbConnection->query($query);
if ($result->num_rows > 0) {
	closeConnection();
	$_SESSION['errorMsg'] = "This Order already exists "; // display error if it doesn't and send back to addOrder page 
	header('location:addOrder.php');
	exit();
}

// check if there is an existing buyer
$query = "SELECT * FROM buyer WHERE Buyer_Id = $Buyer" ;
$result = $dbConnection->query($query);
if ($result->num_rows !=1) {
	closeConnection();
	$_SESSION['errorMsg'] = "This buyer doesn't  exist "; // if no buyer exists send back to addOrder with error
	header('location:addOrder.php');
	exit();
}




// Sanitize strings to make them fit for entry into the database
$Name = sanitizeString($Name);
$Paid = sanitizeString($Paid);
$Date = sanitizeString($Date);
// query to add the values  from the form to the order table
$query = "INSERT INTO order (Order_Id, Quantity, Order_Date, No_of_Varients, Paid_Status, Comic_Name, Comic_Issue, Buyer_Id) VALUES ($ID, $Quantity, '$Date', $Variants, '$Paid', '$Name', $Issue, $Buyer)";
$result = $dbConnection->query($query); // runs the query
if (!$result) {
	$_SESSION['errorMsg'] = "There was a problem with the database: " . $dbConnection->error.$ID.$Quantity.$Date.$Variants.$Paid.$Name.$Issue.$Buyer; // display error if the query fails
	
	closeConnection(); // closes the database connection
	header('location:addOrder.php');
	exit();
}

// everything worked, send back to the orders page
closeConnection();

header('Location:orders.php');
?>