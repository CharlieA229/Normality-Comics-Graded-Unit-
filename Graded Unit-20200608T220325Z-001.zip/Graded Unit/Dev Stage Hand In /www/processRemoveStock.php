<?php
/* This processes the removal of a stock item from the database 
   
*/


require 'database.php';
require 'userSession.php';
// unset any previous error message
unset($_SESSION['errorMsg']);


// connect to the database
if (!connectToDb('normality')) {
	$_SESSION['errorMsg'] = "Sorry, we could not connect to the database.";
	header('location:removeStock.php');
	exit();
}

// after this point we have an open DB connection




// check the form contains all the post data
if (!(isset($_POST["Name"]) && 
	  isset($_POST["Issue"]) 
	  )) {
	header('location:removeStock.php');
	exit();
}

// recover the form data
$Name = trim($_POST["Name"]);
$Issue = ($_POST["Issue"]);







// check if the comic exists
$Name = sanitizeString($Name);

$query = "SELECT * FROM comic WHERE Name='$Name' AND Issue =$Issue"; // create query 
$result = $dbConnection->query($query); // run query 
if ($result->num_rows == 0) { // there is no result returned 
	closeConnection();
	$_SESSION['errorMsg'] = "This Comic does not exist ";  // The comic does not exist 
	header('location:removeStock.php');
	exit();
}

// add the new user details to the database
$Name = sanitizeString($Name);



$query = "DELETE FROM comic WHERE Name='$Name' AND Issue =$Issue"; // make query to delete the matching row 
$result = $dbConnection->query($query); 
if (!$result) {
	$_SESSION['errorMsg'] = "There was a problem with the database: " . $dbConnection->error ; // display an error if the query fails
	
	closeConnection();
	header('location:removeStock.php');
	exit();
}

// everything worked, return to stock page 
closeConnection();


header('Location:stock.php');
?>