<!DOCTYPE html>
<?php
require 'userSession.php';
require 'pageElements.php';
?>

<html>
    <head>
        <title>Normality Comics</title>
    
<?php writeCommonStyles(); ?>		
		
    </head>  
    
    <body>
        <div id="container">
            
            <div id="header"><?php displaySignIn(); ?><h1>Reports Page</h1></div>

			<?php displayMenu(REPORTS); ?>

            <div id="content" style="overflow:auto;">
			
			<h1>Reports Page</h1>
			
			<<p>UNDER CONSTRUCTION 
			
			</div>

              <?php displayFooter(); ?>
        
        </div>
    
    </body>    
</html>