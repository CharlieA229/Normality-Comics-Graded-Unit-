<!DOCTYPE html>
<!--
The page that displays all the order details and gives the options to edit it 
-->

<?php
// get all of the php files required for this page
require 'userSession.php';
require 'pageElements.php';
require 'database.php';
?>

<html>
    <head>
        <title>Normality Comics</title>
    
<?php writeCommonStyles(); ?>		
<link href="css/table.css" rel="stylesheet" type="text/css"/>		
    </head>  
    
    <body>
        <div id="container">
            
            <div id="header"><?php displaySignIn(); ?><h1>Orders Page</h1></div>

			<?php displayMenu(ORDERS); ?>

            <div id="content" style="overflow:auto;">
			
			<h1>Orders</h1>
			
			<?php
			// connect to the database
			if (!connectToDb('normality')) {
			$_SESSION['errorMsg'] = "Sorry, we could not connect to the database.";
			header('location:index.php');
			exit();
			}
			
			// after this point we have an open DB connection
			
			// check table has values
			
			$query = "SELECT * FROM `order`"; // create the needed query 
			$result = $dbConnection->query($query); // run the query in the database
			if ($result->num_rows == 0) {
				closeConnection();
				$_SESSION['errorMsg'] = "Sorry - unexpected problem with the database"; // display error if no values in the table
				header('location:index.php');
				exit();
			}
			// create the table headings
			echo '<table >';
				echo '<thead>';
					echo'<tr>';
						echo'<th> Order ID </th>';
						echo'<th> Quantity  </th>';
						echo'<th> Order Date </th>';
						echo'<th> Number Of Variant Covers </th>';
						echo'<th> Paid Status </th>';
						echo'<th> Comic Name </th>';
						echo'<th> Comic Issue </th>';
						echo'<th> Buyer ID </th>';
					echo'</tr>';
				echo'</thead>';
			
				echo'<tbody>';
			
				// run query to get field from table 
				// use the same query made earlier
				$result = $dbConnection->query($query);
				//for every row in the query results save the rows values as fields 
				while ($row = $result->fetch_assoc()) {
					$field1 = $row["Order_Id"];
					$field2 = $row["Quantity"];
					$field3 = $row["Order_Date"];
					$field4 = $row["No_of_Varients"];
					$field5 = $row["Paid_Status"]; 
					$field6 = $row["Comic_Name"];
					$field7 = $row["Comic_Issue"];
					$field8 = $row["Buyer_Id"];
				
				
				// display the fields in the table
					echo '<tr> 
						<td>'.$field1.'</td> 
						<td>'.$field2.'</td> 
						<td>'.$field3.'</td> 
						<td>'.$field4.'</td> 
						<td>'.$field5.'</td> 
						<td>'.$field6.'</td> 
						<td>'.$field7.'</td> 
						<td>'.$field8.'</td> 
					</tr>';
					
				}
				echo'</tbody>';
			echo'</table>';
    
//https://www.sitepoint.com/community/t/how-to-display-data-from-a-database-into-a-html-table/241123/5
           ?>
			
		<!--
		Form that displays the buttons that allow for the stock to be edited.
		link to the appropriate pages. 
		
		-->
		 <form class = "buttons">
			<input class = "button" type="button" value="AddOrder" onclick="window.location.href='addOrder.php'"/>
			<input class = "button disabled" type="button" value="EditOrder" onclick="window.location.href='editOrder.php'" disabled />
			<input class = "button disabled" type="button" value="RemoveOrder" onclick="window.location.href='removeOrder.php'" disabled  />
		</form>

			
			
			</div>
			    <?php displayFooter(); ?>
        </div>
    
    </body>    
</html>