-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 08, 2019 at 01:13 AM
-- Server version: 5.7.11
-- PHP Version: 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `normality`
--

-- --------------------------------------------------------

--
-- Table structure for table `buyer`
--

CREATE TABLE `buyer` (
  `Buyer_Id` int(4) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Address_Line_1` varchar(30) NOT NULL,
  `Address_Line_2` varchar(20) DEFAULT NULL,
  `Postcode` varchar(10) DEFAULT NULL,
  `Store_Name` varchar(30) DEFAULT NULL,
  `Date_Registered` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buyer`
--

INSERT INTO `buyer` (`Buyer_Id`, `Password`, `Address_Line_1`, `Address_Line_2`, `Postcode`, `Store_Name`, `Date_Registered`) VALUES
(1000, 'Password1000', '221 Zoo Lane', 'Falkirk', 'FK02 6AB', 'Wild Comics', '2019-04-08'),
(1001, 'Password1001', '64 Baker Street', 'Edinburgh', 'EH31 9PB', 'Welcoming Planet', '2019-04-10');

-- --------------------------------------------------------

--
-- Table structure for table `comic`
--

CREATE TABLE `comic` (
  `Name` varchar(30) NOT NULL,
  `Issue` int(4) NOT NULL,
  `Stock_Left` int(3) DEFAULT NULL,
  `Issue_Cost` double(4,2) NOT NULL,
  `Number_of_Requests` int(3) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comic`
--

INSERT INTO `comic` (`Name`, `Issue`, `Stock_Left`, `Issue_Cost`, `Number_of_Requests`) VALUES
('Fe Person ', 1, 200, 2.99, 0),
('Fe Person', 2, 150, 2.49, 0),
('Nurse Weird ', 1, 100, 2.99, 0),
('Protectors Of The Parking Lot', 1, 25, 2.99, 0),
('Quality Quad', 1, 200, 2.99, 0),
('The Canny Chaps', 1, 150, 2.99, 0),
('The Kid Arachnid', 1, 150, 2.99, 0),
('The Mediocre Bulk ', 1, 150, 2.99, 0),
('The Re-payers ', 1, 50, 2.99, 0),
('The Savage Badger ', 1, 30, 2.99, 0),
('The Savage Badger', 2, 50, 2.49, 0);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `Order_Id` int(4) NOT NULL,
  `Quantity` int(3) NOT NULL,
  `Order_Date` date NOT NULL,
  `No_of_Varients` int(3) DEFAULT NULL,
  `Paid_Status` char(1) NOT NULL,
  `Comic_Name` varchar(30) NOT NULL,
  `Comic_Issue` int(4) NOT NULL,
  `Buyer_Id` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`Order_Id`, `Quantity`, `Order_Date`, `No_of_Varients`, `Paid_Status`, `Comic_Name`, `Comic_Issue`, `Buyer_Id`) VALUES
(1, 50, '2019-04-22', 2, 'N', 'Protectors Of The Parking Lot', 1, 1000),
(2, 100, '2019-04-22', 4, 'Y', 'The Savage Badger ', 1, 1001),
(3, 50, '2019-05-02', 2, 'Y', 'Fe Person', 1, 1001),
(4, 100, '2019-05-02', 4, 'Y', 'The Mediocre Bulk ', 1, 1001);

-- --------------------------------------------------------

--
-- Table structure for table `printing_history`
--

CREATE TABLE `printing_history` (
  `Print_Number` int(3) NOT NULL,
  `Print_Date` date NOT NULL,
  `Number_Printed` int(3) NOT NULL,
  `Comic_Name` varchar(30) NOT NULL,
  `Comic_Issue` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserId` int(11) NOT NULL,
  `RealName` varchar(255) NOT NULL,
  `UserName` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` char(60) NOT NULL,
  `Admin` char(1) NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserId`, `RealName`, `UserName`, `Email`, `Password`, `Admin`) VALUES
(1, 'Ian', 'Root', 'argentcharlie@gmail.com', '$2y$10$bBTkfizgnHys9G1bNMXuculXrb5BFLT9uis52W.OQ3FcFBzbPH8Ja', 'Y'),
(3, 'Test', 'Test', '555346@learn.forthvalley.ac.uk', '$2y$10$nuMB4/JGltustJ.WM/d9GO.mkRY4N/I6yKvMIVabmEdqHq106u5iu', 'N');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buyer`
--
ALTER TABLE `buyer`
  ADD PRIMARY KEY (`Buyer_Id`);

--
-- Indexes for table `comic`
--
ALTER TABLE `comic`
  ADD PRIMARY KEY (`Name`,`Issue`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`Order_Id`),
  ADD KEY `Order_Buyer_FK` (`Buyer_Id`),
  ADD KEY `Order_Comic_FK` (`Comic_Name`,`Comic_Issue`);

--
-- Indexes for table `printing_history`
--
ALTER TABLE `printing_history`
  ADD PRIMARY KEY (`Print_Number`),
  ADD KEY `Printing_History_Comic_FK` (`Comic_Name`,`Comic_Issue`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserId`),
  ADD UNIQUE KEY `UserName` (`UserName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `Order_Buyer_FK` FOREIGN KEY (`Buyer_Id`) REFERENCES `buyer` (`Buyer_Id`),
  ADD CONSTRAINT `Order_Comic_FK` FOREIGN KEY (`Comic_Name`,`Comic_Issue`) REFERENCES `comic` (`Name`, `Issue`);

--
-- Constraints for table `printing_history`
--
ALTER TABLE `printing_history`
  ADD CONSTRAINT `Printing_History_Comic_FK` FOREIGN KEY (`Comic_Name`,`Comic_Issue`) REFERENCES `comic` (`Name`, `Issue`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
